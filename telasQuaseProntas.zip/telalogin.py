from kivy.lang import Builder
from kivy.uix.screenmanager import Screen

# Carrega a interface
Builder.load_file('telas/login.kv')

class Login(Screen):
   pass