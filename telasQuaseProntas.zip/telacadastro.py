from kivy.lang import Builder
from kivy.uix.screenmanager import Screen

# Carrega a interface
Builder.load_file('telas/cadastro.kv')

class Cadastro(Screen):
   pass