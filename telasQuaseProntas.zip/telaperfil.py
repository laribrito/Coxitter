from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import Screen

Builder.load_file("telas/perfil.kv")

class Perfil(Screen):
    pass

